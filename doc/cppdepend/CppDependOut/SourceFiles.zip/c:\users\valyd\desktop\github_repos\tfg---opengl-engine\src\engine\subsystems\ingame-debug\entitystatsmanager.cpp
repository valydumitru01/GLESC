/**************************************************************************************************
 * @file   EntityStatsManager.cpp
 * @author Valentin Dumitru
 * @date   08/03/2024
 * @brief  @TODO Add description of this file if needed
 *
 * Copyright (c) 2024 Valentin Dumitru. Licensed under the MIT License.
 * See LICENSE.txt in the project root for license information.
 **************************************************************************************************/
#include "engine/subsystems/ingame-debug/EntityStatsManager.h"


// Define the static members
EntityStatsManager::EntityData EntityStatsManager::entityData{};

